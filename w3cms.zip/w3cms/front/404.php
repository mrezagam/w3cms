<?php require 'header.php'; ?>
404
<?php require 'footer.php'; ?>