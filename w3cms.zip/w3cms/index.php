<?php

require 'core/load.php';

$uri = str_replace(baseUrl, '', (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]");
$uri = strtok($uri, '?');
if ($uri == '/') { $uri = '/base'; }
$uri = explode('/', ltrim($uri, '/'));
$file = implode('.', $uri) . '.php';
if (!file_exists('front/' . $file)) 
{
    $subT = ''; $sub  = [];
    for ($i = 1; $i < count($uri); $i++)
    {
        $sub[] = $uri[$i];
        $subT .= '.sub';
    }
    $file = $uri[0] . $subT . '.php';
    if (!file_exists('front/' . $file)) {$file = '404.php';}
    unset($subT);
}

require  ('front/' . $file);