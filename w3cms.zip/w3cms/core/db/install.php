<?php

require '../load.php';

$column = array(
    "fullname       VARCHAR(64)",
    "mobile         VARCHAR(16)",
    'email          VARCHAR(128)',
    'password       VARCHAR(128)',
    'rol            INT(2)',
    'wallet         INT(9)',
    'online_time    INT(10)',
    'in_time        INT(10)'
);
$sql -> create_table('user', $column); 

$column = array(
    "user_id       int(6)",
    "token         VARCHAR(64)",
    'dvice         VARCHAR(128)',
    'in_time       INT(10)'
);
$sql -> create_table('user_login', $column, 7); 





/*
911111

$array = ['fullname' => 'mrezagam', 'mobile' => '09213161317', 'email' => 'mrezagam@gmail.com'];
//echo sql_insert('user',$array);
*/


//echo $sql -> insert_multiple('user',$array);

/*
$array = sql_select("user","id,fullname","id != 2");
//print_r($array );


echo db_select_dot("user","email","id","2");


//echo sql_delete('user', "id=1");


$array = ['fullname' => 'mrezagam2', 'mobile' => '', 'email' => 'mrezagam@.com'];
//echo sql_update('user', $array, "id=2");
*/

?>