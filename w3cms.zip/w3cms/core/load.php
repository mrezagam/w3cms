<?php

require 'config.php';
require 'class/sql.php';
require 'function/general.php';

$sql = new sql(dbInfo);


?>