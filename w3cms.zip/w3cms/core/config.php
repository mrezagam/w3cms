<?php

define("dbInfo",array
(
    "host"  =>  "localhost",
    "user"  =>  "root",
    "pass"  =>  "",
    "name"  =>  "w3cms"
));

define("baseUrl",'http://localhost/w3cms');

?>